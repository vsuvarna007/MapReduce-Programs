import java.io.*;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class Partition_Category {

	public static class InputMapClass extends Mapper<LongWritable,Text,Text,Text>
	{
		public void map(LongWritable key, Text value, Context context)
		{
			try
			{
				String find[] = value.toString().split(",");
				String custid = find[2];
				String category = find[4];
				String amt = find[3];
				String total = amt+","+category;
				context.write(new Text(custid),new Text(total));
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
	
	public static class CaderPartitioner extends
	   Partitioner < Text, Text >
	   {
	      @Override
	      public int getPartition(Text key, Text value, int numReduceTasks)
	      {
	         String[] str = value.toString().split(",");
	         if(str[1].equals("Exercise & Fitness"))
	         {
	            return 0;
	         }
	         else if (str[1].equals("Gymnastics"))
	         {
	            return 1 ;
	         }
	         else if (str[1].equals("Team Sports"))
	         {
	        	 return 2;
	         }
	         else if (str[1].equals("Outdoor Recreation"))
	         {
	        	 return 3;
	         }
	         else if (str[1].equals("Puzzles"))
	         {
	        	 return 4;
	         }
	         else if (str[1].equals("Air Sports"))
	         {
	        	 return 5;
	         }
	         else if (str[1].equals("Combat Sports"))
	         {
	        	 return 6;
	         }
	         else if (str[1].equals("Dancing"))
	         {
	        	 return 7;
	         }
	         else if (str[1].equals("Games"))
	         {
	        	 return 8;
	         }
	         else if (str[1].equals("Indoor Games"))
	         {
	        	 return 9;
	         }
	         else if (str[1].equals("Racquet Sports"))
	         {
	        	 return 10;
	         }
	         else if (str[1].equals("Jumping"))
	         {
	        	 return 11;
	         }
	         else if (str[1].equals("Water Sports"))
	         {
	        	 return 12;
	         }
	         else if (str[1].equals("Winter Sports"))
	         {
	        	 return 13;
	         }
	         //Outdoor Play Equipment
	         else
	         {
	        	 return 14;
	         }
	      }
	   }

	public static class InputReduceClass extends Reducer<Text,Text,Text,DoubleWritable>
	{
		private DoubleWritable result = new DoubleWritable();

		public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
			double sum = 0;

			for (Text val : values)
			{       	
				String data[] = val.toString().split(","); 
				sum += Double.parseDouble(data[0]);
			}		 
			result.set(sum);
			context.write(key, result);
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		//conf.set("name", "value")
		Job job = Job.getInstance(conf, "Phone Calls");
		job.setJarByClass(Partition_Category.class);
		job.setMapperClass(InputMapClass.class);
		job.setPartitionerClass(CaderPartitioner.class);
		//job.setCombinerClass(ReduceClass.class);
		job.setReducerClass(InputReduceClass.class);
		job.setNumReduceTasks(15);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}