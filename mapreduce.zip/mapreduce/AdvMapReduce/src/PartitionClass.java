import java.io.*;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class PartitionClass {

	public static class InputMapClass extends Mapper<LongWritable,Text,Text,Text>
	{
		public void map(LongWritable key, Text value, Context context)
		{
			try
			{
				String data[] = value.toString().split(",");
				String name = data[1];
				String age = data[2];
				String gender = data[3];
				String salary = data[4];
				String value1 = name+","+age+","+salary;
				context.write(new Text(gender),new Text(value1));
			}
			catch(Exception e)
			{
				System.out.println("Error"+e);
			}
		}
	}
	
	public static class CaderPartitioner extends
	   Partitioner < Text, Text >
	   {
	      @Override
	      public int getPartition(Text key, Text value, int numReduceTasks)
	      {
	         String[] str = value.toString().split(",");
	         int age = Integer.parseInt(str[1]);


	         if(age<=20)
	         {
	            return 0;
	         }
	         else if(age>20 && age<=30)
	         {
	            return 1 ;
	         }
	         else
	         {
	            return 2;
	         }
	      }
	   }

	public static class InputReduceClass extends Reducer<Text,Text,Text,DoubleWritable>
	{
		private DoubleWritable result = new DoubleWritable();

		public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException 
		{
			double max=0;
			String mykey ="";
			for (Text val : values)
			{       	
				String data[] = val.toString().split(",");
				double salary = Double.parseDouble(data[2]);
				if(salary>max)
				{
					max=salary;
					mykey = data[0]+","+data[1]+","+key.toString();
				}
			}		 
			result.set(max);
			
			context.write(new Text(mykey), result);
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Phone Calls");
		job.setJarByClass(PartitionClass.class);
		job.setMapperClass(InputMapClass.class);
		//job.setCombinerClass(InputReduceClass.class);
		job.setReducerClass(InputReduceClass.class);
		job.setPartitionerClass(CaderPartitioner.class);
		job.setNumReduceTasks(3);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}