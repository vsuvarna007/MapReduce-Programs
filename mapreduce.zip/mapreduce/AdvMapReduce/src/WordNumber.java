import java.io.*;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class WordNumber {

	public static class WordNumberMapper extends Mapper<LongWritable,Text,Text,IntWritable>
	{
		public static final LongWritable a = new LongWritable(1);
		private Map<String, Integer> abMap = new HashMap<String, Integer>();
		protected void setup(Context context) throws java.io.IOException, InterruptedException{

			super.setup(context);

			URI[] files = context.getCacheFiles(); // getCacheFiles returns null

			Path p = new Path(files[0]);

			if (p.getName().equals("AFINN.txt")) {
				BufferedReader reader = new BufferedReader(new FileReader(p.toString()));
				String line = reader.readLine();
				while(line != null) {
					String[] tokens = line.split("\t");
					String word = tokens[0];
					int number = Integer.parseInt(tokens[1]);
					abMap.put(word, number);
					line = reader.readLine();
				}
				reader.close();
			}
			if (abMap.isEmpty()) 
			{
				throw new IOException("MyError:Unable to load afinn data.");
			}
		}
		String myWord="";
		
		public void map(LongWritable key, Text value, Context context)
		{
			int myValue=0;
			try
			{
				StringTokenizer st = new StringTokenizer(value.toString());
				while(st.hasMoreTokens())
				{
					myWord = st.nextToken().toLowerCase();
					
					if(abMap.get(myWord)!=null)
					{
						myValue = abMap.get(myWord);
						if(myValue>0)
						{
							myWord = "positive";
						}
						if(myValue<0)
						{
							myWord = "negative";
							myValue *= -1;
						}
					}
					else
					{
						myWord = "positive";
						myValue = 0;
					}
					context.write(new Text(myWord), new IntWritable(myValue));
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

	public static class WordNumberReducer extends Reducer<Text,IntWritable,NullWritable,Text>
	{
		long total_pos=0,total_neg=0;
		public void reduce(Text key, Iterable<IntWritable> values,Context context) throws IOException, InterruptedException {
			long sum = 0;

			for (IntWritable val : values)
			{       	
				sum += val.get();      
			}
			if(key.toString().equals("positive"))
			{
				total_pos=sum;
			}
			else if(key.toString().equals("negative"))
			{
				total_neg=sum;
			}
		}
		
		protected void cleanup(Context context) throws IOException,
		InterruptedException {
		// Output our 5 records to the reducers with a null key
		double sentiment =(((double)total_pos-(double)total_neg)/((double)total_pos+(double)total_neg));
		sentiment*=100;
		String str = String.format("%.2f", sentiment);
		String str2 = " \nTotal Positive "+total_pos+" Total Negative"+total_neg;
		context.write(null, new Text("The Sentiment Analysis is "+ str+"%"+str2));
		}
		
	}
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		//conf.set("name", "value")
		Job job = Job.getInstance(conf, "Sentiment");
		job.setJarByClass(WordNumber.class);
		job.setMapperClass(WordNumberMapper.class);
		job.addCacheFile(new Path("AFINN.txt").toUri());
		//job.setCombinerClass(ReduceClass.class);
		job.setReducerClass(WordNumberReducer.class);
		//job.setNumReduceTasks(0);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}