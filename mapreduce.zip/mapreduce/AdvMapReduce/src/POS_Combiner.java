import java.io.*;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.conf.*;

import org.apache.hadoop.fs.*;

import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

import org.apache.hadoop.util.*;

public class POS_Combiner extends Configured implements Tool
{
   //Map class
	
   public static class MapClass extends Mapper<LongWritable,Text,Text,IntWritable>
   {
      public void map(LongWritable key, Text value, Context context)
      {
         try{
            String[] str = value.toString().split(",");
            int qty=Integer.parseInt(str[1]);
            int cost=Integer.parseInt(str[2]);
            int total=qty*cost;
            String state=str[3];
            context.write(new Text(state), new IntWritable(total));
         }
         catch(Exception e)
         {
            System.out.println(e);
         }
      }
   }
   
   //Reducer class
	
   public static class ReduceClass extends Reducer<Text,IntWritable,Text,IntWritable>
   {
      private IntWritable result = new IntWritable();

      public void reduce(Text key, Iterable <IntWritable> values, Context context) throws IOException, InterruptedException
      {
         
    	  int sum = 0;
          for (IntWritable val : values) {
              
        	sum += val.get();
          }
          result.set(sum);
          context.write(key, result);
      }
   }
   
   //Partitioner class
	
   public static class CaderPartitioner extends
   Partitioner < Text, IntWritable >
   {
      @Override
      public int getPartition(Text key, IntWritable value, int numReduceTasks)
      {
         String str = key.toString();
         if(str.equals("MAH"))
         {
            return 0;
         }
         else
         {
            return 1 ;
         }
      }
   }
   

   public int run(String[] arg) throws Exception
   {
	
	   
	  Configuration conf = new Configuration();
	  Job job = Job.getInstance(conf);
	  job.setJarByClass(POS_Combiner.class);
	  job.setJobName("State Wise Item Qty sales");
      
		
      job.setMapperClass(MapClass.class);
		
      job.setMapOutputKeyClass(Text.class);
      job.setMapOutputValueClass(IntWritable.class);
      
      //set partitioner statement
      job.setCombinerClass(ReduceClass.class);
      job.setPartitionerClass(CaderPartitioner.class);
      job.setReducerClass(ReduceClass.class);
      job.setNumReduceTasks(2);
      //job.setInputFormatClass(TextInputFormat.class);
		
      //job.setOutputFormatClass(TextOutputFormat.class);
      job.setOutputKeyClass(Text.class);
      job.setOutputValueClass(IntWritable.class);
      FileInputFormat.setInputPaths(job, new Path(arg[0]));
      FileOutputFormat.setOutputPath(job,new Path(arg[1]));
     
      System.exit(job.waitForCompletion(true)? 0 : 1);
      return 0;
   }
   
   public static void main(String ar[]) throws Exception
   {
      ToolRunner.run(new Configuration(), new POS_Combiner(),ar);
      System.exit(0);
   }
}