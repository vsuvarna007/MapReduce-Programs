import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class TopProducts {
	public static class TopPMapper extends
	Mapper<LongWritable, Text, Text, DoubleWritable> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			double p_qty = Double.parseDouble(parts[8]);
			String p_id = parts[5];
			context.write(new Text(p_id), new DoubleWritable(p_qty));
		}
	}

	public static class TopPReducer extends
	Reducer<Text, DoubleWritable, NullWritable, Text> {
		private TreeMap<Double, Text> repToRecordMap = new TreeMap<Double, Text>();

		public void reduce(Text key, Iterable<DoubleWritable> values,
				Context context) throws IOException, InterruptedException {
			double sum=0;
			String myValue ="";
				for (DoubleWritable value : values) {
					sum+=value.get();
					myValue=key.toString()+";"+sum;
				}
				
				repToRecordMap.put(sum, new Text(myValue));
				
				if (repToRecordMap.size() > 4) {
							repToRecordMap.remove(repToRecordMap.firstKey());
						}
		}
		protected void cleanup(Context context) throws IOException,
		InterruptedException {
		// Output our 5 records to the reducers with a null key
		for (Text t : repToRecordMap.descendingMap().values()) {
		context.write(NullWritable.get(), t);
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(TopProducts.class);
	    job.setMapperClass(TopPMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setReducerClass(TopPReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(DoubleWritable.class);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
