import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class AVGCost {
	public static class AVGCostMapper extends
	Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			long p_qty = Long.parseLong(parts[6]);
			long p_cost = Long.parseLong(parts[7]);
			String myValue = p_qty+","+p_cost;
			String p_id = parts[5];
			context.write(new Text(p_id), new Text(myValue));
		}
	}

	public static class AVGCostReducer extends
	Reducer<Text, Text, Text, DoubleWritable> 
	{
		public void reduce(Text key, Iterable<Text> values,
				Context context) throws IOException, InterruptedException 
				{
			long total_cost=0,total_qty=0;
			double avg=0;
			for (Text value : values) {
				String[] record = value.toString().split(",");
				total_cost+=Long.parseLong(record[1]);
				total_qty+=Long.parseLong(record[0]);
			}
			avg= Math.round((double)total_cost/(double)total_qty);
			avg = Double.parseDouble(new DecimalFormat("##.##").format(avg));
			context.write(key, new DoubleWritable(avg));
				}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(AVGCost.class);
	    job.setMapperClass(AVGCostMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setReducerClass(AVGCostReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(DoubleWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
