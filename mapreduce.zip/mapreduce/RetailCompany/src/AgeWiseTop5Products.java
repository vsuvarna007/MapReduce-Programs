import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class AgeWiseTop5Products {
	public static class AgeWiseTop5ProductsMapper extends
	Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			long p_sales = Long.parseLong(parts[8]);
			long p_cost = Long.parseLong(parts[7]);
			String age =parts[2];
			String p_id = parts[5];
			String myValue=p_sales+","+p_cost+","+age;
			context.write(new Text(p_id), new Text(myValue));
		}
	}
	
	 //Partitioner class
	
	   public static class CaderPartitioner extends
	   Partitioner < Text, Text >
	   {
	      @Override
	      public int getPartition(Text key, Text value, int numReduceTasks)
	      {
	         String[] str = value.toString().split(",");
	         String age = str[2].trim();
	         if(age.equals("A"))
	         {
	            return 0;
	         }
	         if(age.equals("B"))
	         {
	            return 1;
	         }
	         if(age.equals("C"))
	         {
	            return 2;
	         }
	         if(age.equals("D"))
	         {
	            return 3;
	         }
	         if(age.equals("E"))
	         {
	            return 4;
	         }
	         if(age.equals("F"))
	         {
	            return 5;
	         }
	         if(age.equals("G"))
	         {
	            return 6;
	         }
	         if(age.equals("H"))
	         {
	            return 7;
	         }
	         if(age.equals("I"))
	         {
	            return 8;
	         }
	         else
	         {
	            return 9 ;
	         }
	      }
	   }

	public static class AgeWiseTop5ProductsReducer extends
	Reducer<Text, Text, NullWritable, Text> {
		private TreeMap<Double, Text> repToRecordMap = new TreeMap<Double, Text>();

		public void reduce(Text key, Iterable<Text> values,
				Context context) throws IOException, InterruptedException {
			long total_sales=0,total_cost=0;
					double profit=0;
			String myValue ="";
				for (Text value : values) {
					String[] data = value.toString().split(",");
					total_sales+=Long.parseLong(data[0]);
					total_cost+=Long.parseLong(data[1]);
					String age = data[2];
					myValue=key.toString()+","+total_sales+","+total_cost+","+age;
				}
				
				profit = total_sales-total_cost;
				
				repToRecordMap.put(profit, new Text(myValue));
				
				if (repToRecordMap.size() > 5) {
							repToRecordMap.remove(repToRecordMap.firstKey());
						}
		}
		protected void cleanup(Context context) throws IOException,
		InterruptedException {
		// Output our 5 records to the reducers with a null key
		for (Text t : repToRecordMap.descendingMap().values()) {
		context.write(NullWritable.get(), t);
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(AgeWiseTop5Products.class);
	    job.setMapperClass(AgeWiseTop5ProductsMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setPartitionerClass(CaderPartitioner.class);
	    job.setReducerClass(AgeWiseTop5ProductsReducer.class);
	    job.setNumReduceTasks(10);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
