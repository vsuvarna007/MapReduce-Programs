import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class AreaWiseCustomer {
	public static class AreaWiseCustomerMapper extends
	Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			String pincode = parts[3];
			String c_id = parts[1];
			context.write(new Text(c_id), new Text(pincode));
		}
	}
	
	  //Partitioner class
	
	   public static class AreaWiseCustomerPartitioner extends
	   Partitioner < Text, Text >
	   {
	      @Override
	      public int getPartition(Text key, Text value, int numReduceTasks)
	      {
	         String pincode = value.toString().trim();
	         if(pincode.equals("A"))
	         {
	            return 0;
	         }
	         else if(pincode.equals("B"))
	         {
	            return 1 ;
	         }
	         else if(pincode.equals("C"))
	         {
	        	 return 2;
	         }
	         else if(pincode.equals("D"))
	         {
	        	 return 3;
	         }
	         else if(pincode.equals("E"))
	         {
	        	 return 4;
	         }
	         else if(pincode.equals("F"))
	         {
	        	 return 5;
	         }
	         else if(pincode.equals("G"))
	         {
	        	 return 6;
	         }
	         else if(pincode.equals("H"))
	         {
	        	 return 7;
	         }
	         else
	         {
	        	 return 8;
	         }
	      }
	   }

	public static class AreaWiseCustomerReducer extends
	Reducer<Text, Text, Text, LongWritable> 
	{
		public void reduce(Text key, Iterable<Text> values,
				Context context) throws IOException, InterruptedException 
				{
			long count=0;
			for (Text value : values) {
				count++;
			}
			context.write(key, new LongWritable(count));
				}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(AreaWiseCustomer.class);
	    job.setMapperClass(AreaWiseCustomerMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setPartitionerClass(AreaWiseCustomerPartitioner.class);
	    job.setReducerClass(AreaWiseCustomerReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(LongWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
