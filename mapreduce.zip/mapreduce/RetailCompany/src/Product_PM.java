import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Product_PM {
	public static class TopPMapper extends
	Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			double sales = Double.parseDouble(parts[8]);
			double cost = Double.parseDouble(parts[7]);
			int qty = Integer.parseInt(parts[6]);
			String myValue = sales+","+cost+","+qty;
			String p_id = parts[5];
			context.write(new Text(p_id), new Text(myValue));
		}
	}

	public static class TopPReducer extends
	Reducer<Text, Text, NullWritable, Text> {
		private TreeMap<Double, Text> repToRecordMap = new TreeMap<Double, Text>();

		public void reduce(Text key, Iterable<Text> values,
				Context context) throws IOException, InterruptedException {
			double total_sales=0,total_cost=0,total_qty=0;
			double margin =0;
			String myValue ="";
				for (Text value : values) {
					String[] record = value.toString().split(",");
					total_sales+=Double.parseDouble(record[0]);
					total_cost+=Double.parseDouble(record[1]);
					total_qty+=Double.parseDouble(record[2]);
					}
				double profit= total_sales-total_cost;
				if(total_cost!=0)
				{
					margin = ((total_sales-total_cost)*100)/total_cost;
				}
				else
				{
					margin = ((total_sales-total_cost)*100);
				}
				myValue=key.toString()+","+profit+","+margin+","+total_qty;
				
				
				
				repToRecordMap.put(margin, new Text(myValue));
				
		}
		protected void cleanup(Context context) throws IOException,
		InterruptedException {
		// Output our 5 records to the reducers with a null key
		for (Text t : repToRecordMap.descendingMap().values()) {
		context.write(NullWritable.get(), t);
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(Product_PM.class);
	    job.setMapperClass(TopPMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setReducerClass(TopPReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
