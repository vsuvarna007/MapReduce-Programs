import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class DayWiseCount {
	public static class DayWiseCountMapper extends
	Mapper<LongWritable, Text, Text, LongWritable> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			long p_sales = Long.parseLong(parts[8]);
			String day = toDay(parts[0]);
			context.write(new Text(day), new LongWritable(p_sales));
		}
		public String toDay(String date)
		{
			SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat day = new SimpleDateFormat("EEEE");
			Date datefrm=null;
			try
			{
				datefrm = dformat.parse(date);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return day.format(datefrm);
		}
	}

	public static class DayWiseCountReducer extends
	Reducer<Text, LongWritable, Text, Text> {
		long grand_total=0;
		private TreeMap<Long, Text> repToRecordMap = new TreeMap<Long, Text>();
		public void reduce(Text key, Iterable<LongWritable> values,
				Context context) throws IOException, InterruptedException {
			long total_sales=0;
			
			String myValue ="";
			for (LongWritable value : values) {
				total_sales+=value.get();
				grand_total+=value.get();
			}
			myValue = key.toString()+","+total_sales;
			
			repToRecordMap.put(total_sales, new Text(myValue));
		}
		protected void cleanup(Context context) throws IOException,
		InterruptedException {
		
			String myText = "";
			String myValue="";
		for (Text t : repToRecordMap.descendingMap().values()) {
			String[] data = t.toString().split(",");
			long total_sales = Long.parseLong(data[1]);
			double percentage = ((double)total_sales/(double)grand_total)*100;
			myText = data[0];
			myValue= total_sales+","+percentage;
		context.write(new Text(myText), new Text(myValue));
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Total Customer Count");
	    job.setJarByClass(DayWiseCount.class);
	    job.setMapperClass(DayWiseCountMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setReducerClass(DayWiseCountReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(LongWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
