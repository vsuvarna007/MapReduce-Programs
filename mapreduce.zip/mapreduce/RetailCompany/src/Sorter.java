import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class Sorter {
	public static class SorterMapper extends
	Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(",");
			String myValue = parts[0]+","+parts[1]+","+parts[2]+","+parts[3]+","+parts[4];
			String myKey = parts[4];
			context.write(new Text(myKey), new Text(myValue));
		}
	}
	
	public static class SorterReducer extends
	Reducer<Text, Text, Text, Text> 
	{
		public void reduce(Text key, Iterable<Text> values,
				Context context) throws IOException, InterruptedException 
				{
			String myValue="";
			for (Text value : values) {
				myValue = value.toString();
				context.write(key, new Text(myValue));
			}
			
				}
	}
	
	static class MyKeyComparator extends WritableComparator
	{
		private static final Text.Comparator TEXT_COMPARATOR = new Text.Comparator();
		
		protected MyKeyComparator()
		{
			super(Text.class);
		}
		
		@SuppressWarnings(value = { "rawtypes" })
		public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
            return (-1)*TEXT_COMPARATOR.compare(b1, s1, l1, b2, s2, l2);
        }
		
		@SuppressWarnings("rawtypes")
		@Override
		public int compare( WritableComparable w1, WritableComparable w2)
		{
			return -super.compare(w1, w2);
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top 5 Records");
	    job.setJarByClass(Sorter.class);
	    job.setMapperClass(SorterMapper.class);
	    //job.setCombinerClass(TopPReducer.class);
	    job.setSortComparatorClass(MyKeyComparator.class);
	    job.setReducerClass(SorterReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
