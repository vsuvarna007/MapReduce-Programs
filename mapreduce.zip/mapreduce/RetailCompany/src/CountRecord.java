import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class CountRecord {
	public static class CountRecordMapper extends
	Mapper<LongWritable, Text, NullWritable, LongWritable> {

		public void map(LongWritable key, Text value, Context context
        ) throws IOException, InterruptedException {
			String record = value.toString();
			String[] parts = record.split(";");
			long p_sales = Long.parseLong(parts[8]);
			context.write(NullWritable.get(), new LongWritable(p_sales));
		}
	}

	public static class CountRecordReducer extends
	Reducer<NullWritable, LongWritable, NullWritable, LongWritable> {
		public void reduce(NullWritable key, Iterable<LongWritable> values,
				Context context) throws IOException, InterruptedException {
			long total_sales=0;
			//int count=0;
			//String myValue ="";
			for (LongWritable value : values) {
				total_sales+=value.get();
				//count++;
			}
			//myValue = total_sales+","+count;
			context.write(NullWritable.get(), new LongWritable(total_sales));
		}
	}
	
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Total Customer Count");
	    job.setJarByClass(CountRecord.class);
	    job.setMapperClass(CountRecordMapper.class);
	    job.setCombinerClass(CountRecordReducer.class);
	    job.setReducerClass(CountRecordReducer.class);
	    job.setMapOutputKeyClass(NullWritable.class);
	    job.setMapOutputValueClass(LongWritable.class);
	    job.setOutputKeyClass(NullWritable.class);
	    job.setOutputValueClass(LongWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
